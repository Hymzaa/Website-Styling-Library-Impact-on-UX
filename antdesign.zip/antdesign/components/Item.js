import styles from "../styles/Item.module.css";

export const Item = ({ children }) => {
  return <div className={styles.listItem}>{children}</div>;
};

export default Item;
