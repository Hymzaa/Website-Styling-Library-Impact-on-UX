import style from "../styles/showPrice.module.css";

import { formatPrice } from "../util/basketPricing";

export const ShowPrice = ({ product }) => {
  if (product.price != product.original_price) {
    return (
      <div>
        <div className={style.originalPrice}>
          {formatPrice(product.original_price)}
          <br />
        </div>
        <div className={style.discountPrice}>{formatPrice(product.price)}</div>
      </div>
    );
  }
  return <div>{formatPrice(product.price)}</div>;
};
