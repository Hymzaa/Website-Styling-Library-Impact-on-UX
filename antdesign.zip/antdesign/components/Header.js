import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/router";

import { basketTotal, formatPrice } from "../util/basketPricing";
import useBasket from "../state/useBasket";

import styles from "../styles/Header.module.css";
import categories from "../data/categories.json";
import useAuth from "../state/useAuth";
import { isEmptyObject } from "../util/miscellaneous";
import { Button, Input, Tag, Typography } from "antd";

export const Header = () => {
  const router = useRouter();

  const _basket = useBasket((state) => state.basket);
  const [basket, setBasket] = useState([]);

  const logout = useAuth((state) => state.logout);
  const _user = useAuth((state) => state.user);
  const [user, setUser] = useState(null);

  useEffect(() => {
    setBasket(_basket);
    setUser(_user);
  }, [_basket, _user]);

  const handleAccountClick = () =>
    router.push(!isEmptyObject(user) ? `/account` : `/authenticate`);

  const handleLogoutClick = () => logout();

  const onSearch = (value) => router.push(`/search?=${value}`);

  return (
    <header>
      <div className={styles.userDetailsWrapper}>
        <div className={styles.userDetails}>
          <a className={styles.account} onClick={handleAccountClick}>
            <Button type="text">
              {!isEmptyObject(user) ? `Account: ${user.name}` : "Login"}
            </Button>
          </a>
          {!isEmptyObject(user) ? (
            <Button type="text" onClick={handleLogoutClick}>
              Logout
            </Button>
          ) : (
            <></>
          )}
          <Link href={`/checkout`}>
            <Button type="text">
              Basket {formatPrice(basketTotal(basket))}
            </Button>
          </Link>
        </div>
      </div>
      <div className={styles.brandAndSearchWrapper}>
        <div className={styles.brandAndSearch}>
          <Link href={`/`}>
            <a>
              <Typography.Title>Good Grocery</Typography.Title>
            </a>
          </Link>
          <div className={styles.searchWrapper}>
            <Input.Search
              placeholder="Search for products"
              enterButton="Search"
              size="large"
              onSearch={onSearch}
            />
          </div>
        </div>
      </div>
      <div className={styles.categoriesWrapper}>
        <div className={styles.categories}>
          {categories.map((category) => {
            return (
              <div key={category.id}>
                <Link href={`/category/${category.id}`}>
                  <Tag>{category.label}</Tag>
                  {/*<span>{category.label}</span>*/}
                </Link>
              </div>
            );
          })}
        </div>
      </div>
    </header>
  );
};
