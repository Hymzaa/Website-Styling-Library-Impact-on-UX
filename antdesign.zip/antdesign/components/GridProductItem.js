import style from "../styles/GridProductItem.module.css";
import Link from "next/link";
import { Typography } from "antd";

export const GridProductItem = ({ product, img }) => {
  return (
    <Link href={`/product/${product.id}`}>
      <div className={style.gridItem}>
        {img}
        <Typography.Title level={4} style={{ textAlign: "center" }}>
          {product.name}
        </Typography.Title>
      </div>
    </Link>
  );
};
