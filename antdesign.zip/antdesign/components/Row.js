import styles from "../styles/Row.module.css";

export const Row = ({children}) => {
  return (
    <div className={styles.buttonGroupWrapper}>
      {children}
    </div>
  );
};
