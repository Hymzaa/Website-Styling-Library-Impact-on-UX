import styles from "../styles/Footer.module.css";
import { Typography } from "antd";

export const Footer = () => {
  return (
    <div className={styles.footerWrapper}>
      <footer className={styles.footer}>
        <Typography.Text level={5}>
          Copyright TM, Dissertation Artefact 2022
        </Typography.Text>
      </footer>
    </div>
  );
};
