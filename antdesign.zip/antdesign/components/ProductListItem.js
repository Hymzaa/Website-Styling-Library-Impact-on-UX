import styles from "../styles/ProductListItem.module.css";
import Link from "next/link";
import Image from "next/image";
import { ShowPrice } from "./ShowPrice";
import { Button } from "antd";

export const ProductListItem = ({ product, detailFr = 3 }) => {
  const { id, name, image_url } = product;
  console.log(product);
  return (
    <Link href={`/product/${id}`}>
      <div
        className={styles.rootWrapper}
        style={{ gridTemplateColumns: `1fr ${detailFr}fr` }}
      >
        <div className={styles.imageWrapper}>
          <Image
            src={image_url}
            layout="fill"
            objectFit="contain"
            alt="Placeholder"
          />
        </div>
        <div>
          <h3 className={styles.productName}>{name}</h3>
          <div style={{ margin: "5px 0" }}>
            Price: <ShowPrice product={product} />
          </div>
          <Button type="primary">View Product</Button>
        </div>
      </div>
    </Link>
  );
};
