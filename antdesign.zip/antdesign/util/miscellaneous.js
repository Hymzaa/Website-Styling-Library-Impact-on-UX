export function timeout(delay) {
  return new Promise((res) => setTimeout(res, delay));
}

export function isEmptyObject(obj) {
  let name;
  for (name in obj) {
    return false;
  }
  return true;
}
