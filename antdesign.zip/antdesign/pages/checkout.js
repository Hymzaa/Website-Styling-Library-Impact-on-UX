import { useEffect, useState } from "react";
import Link from "next/link";

import { Layout } from "../components/Layout";
import useBasket from "../state/useBasket";
import { Row } from "../components/Row";

import styles from "../styles/checkout.module.css";
import { formatPrice } from "../util/basketPricing";
import useAuth from "../state/useAuth";
import { isEmptyObject } from "../util/miscellaneous";
import { ProductListItem } from "../components/ProductListItem";
import { Button, Card, List, Radio, Typography } from "antd";

export default function Checkout() {
  const updateQuantity = useBasket((state) => state.updateQuantity);
  const clearBasket = useBasket((state) => state.clearBasket);

  const _user = useAuth((state) => state.user);
  const [user, setUser] = useState(null);

  const _basket = useBasket((state) => state.basket);
  const [basket, setBasket] = useState([]);

  useEffect(() => {
    setUser(_user);
    setBasket(_basket);
  }, [_user, _basket]);

  // calculations
  const subtotal = (item) => item.quantity * item.product.price;
  const total = () =>
    basket.reduce((sum, item) => sum + item.quantity * item.product.price, 0);

  // intents
  const increase = (item) => updateQuantity(item.product, item.quantity + 1);
  const decrease = (item) => updateQuantity(item.product, item.quantity - 1);
  const remove = (item) => updateQuantity(item.product, 0);

  const handleContinue = () => {
    if (isEmptyObject(user)) {
      alert("Please sign in to continue checkout.");
    } else {
      alert("Your order has been placed!");
      clearBasket();
    }
  };

  // payment option (radio button group)
  const [value, setValue] = useState("VISA 8734");
  const onChange = (e) => {
    console.log("radio checked", e.target.value);
    setValue(e.target.value);
  };

  return (
    <Layout>
      <Typography.Title level={2}>Checkout</Typography.Title>
      {basket.length === 0 ? (
        <>
          <h3>Empty Basket</h3>
        </>
      ) : (
        <div className={styles.checkoutBasketWrapper}>
          <div>
            <List
              bordered
              dataSource={basket}
              renderItem={(item) => (
                <List.Item style={{ backgroundColor: "white" }}>
                  <Link href={`/product/${item.product.id}`}>
                    <div className={styles.basketItem}>
                      <ProductListItem
                        key={item.product.id}
                        product={item.product}
                        detailFr={2}
                      />
                    </div>
                  </Link>

                  <div className={styles.basketItemQuanSubControls}>
                    <Typography.Paragraph>
                      Subtotal: {formatPrice(subtotal(item))}
                    </Typography.Paragraph>

                    <Row>
                      <Button size="small" onClick={() => decrease(item)}>
                        -1
                      </Button>
                      <span>{item.quantity}</span>
                      <Button size="small" onClick={() => increase(item)}>
                        +1
                      </Button>
                      <Button
                        size="small"
                        type="danger"
                        onClick={() => remove(item)}
                      >
                        Remove
                      </Button>
                    </Row>
                  </div>
                </List.Item>
              )}
            />
            <Button
              style={{ marginTop: 20 }}
              onClick={clearBasket}
              danger
              type="primary"
            >
              Clear Basket
            </Button>
          </div>
          <div className={styles.paymentWrapper}>
            <Card
              title={
                <Typography.Title level={3}>Confirm Order</Typography.Title>
              }
            >
              <div className={styles.prices}>
                <Typography.Text>
                  Total (excl. VAT): {formatPrice(total() * 0.8)}
                </Typography.Text>
                <Typography.Text>
                  VAT (20%): {formatPrice(total() * 0.2)}
                </Typography.Text>
                <Typography.Text className={styles.total}>
                  Total incl. taxes: {formatPrice(total())}
                </Typography.Text>
              </div>
            </Card>
            <Card
              title={
                <Typography.Title level={3}>Delivery Address</Typography.Title>
              }
            >
              <Card type="inner">
                <Typography.Paragraph>71 Kingsway</Typography.Paragraph>
                <Typography.Paragraph>London</Typography.Paragraph>
                <Typography.Paragraph>NW59 0WT</Typography.Paragraph>
                <Button>Update</Button>
              </Card>
            </Card>
            <Card
              title={
                <Typography.Title level={3}>Payment Method</Typography.Title>
              }
              actions={[
                <Button
                  key="confirm-order"
                  onClick={handleContinue}
                  type="primary"
                  size="large"
                >
                  Confirm Order
                </Button>,
              ]}
            >
              <Radio.Group
                onChange={onChange}
                value={value}
                style={{ width: "100%" }}
              >
                <List
                  bordered
                  dataSource={[
                    {
                      name: "VISA 8734",
                      expiry: "07/25",
                    },
                    {
                      name: "AMEX 3492",
                      expiry: "07/25",
                    },
                  ]}
                  renderItem={(item) => (
                    <List.Item
                      style={{ display: "flex", alignItems: "center" }}
                    >
                      {/*<Typography.Text mark>[ITEM]</Typography.Text> {item.name}*/}
                      <Radio value={item.name}></Radio>
                      <div
                        style={{
                          marginLeft: 10,
                          display: "flex",
                          flexDirection: "column",
                        }}
                      >
                        <Typography.Text>
                          <b>{item.name}</b>
                        </Typography.Text>
                        <Typography.Text>{item.expiry}</Typography.Text>
                      </div>
                      <Button style={{ marginLeft: "auto" }}>Edit</Button>
                    </List.Item>
                  )}
                />
              </Radio.Group>
            </Card>
          </div>
        </div>
      )}
    </Layout>
  );
}
