import { Layout } from "../components/Layout";
import { fetchAllProducts } from "../lib/products";
import styles from "../styles/category.[id].module.css";
import { ProductListItem } from "../components/ProductListItem";
import { List, Typography } from "antd";

export default function Search({ searchTerm, results }) {
  return (
    <Layout>
      <Typography.Title level={2}>
        Search: &quot;{searchTerm}&quot;
      </Typography.Title>

      <List
        bordered
        dataSource={results}
        renderItem={(product) => (
          <div className={styles.productList}>
            <ProductListItem key={product.id} product={product} />
          </div>
        )}
      />
    </Layout>
  );
}

export async function getServerSideProps({ query }) {
  // the query term is default bc there is no named url params
  const searchTerm = query[""];

  const allProducts = await fetchAllProducts();

  const results = allProducts.filter(
    (product) => product.name.toLowerCase() === searchTerm.toLowerCase()
  );

  return {
    props: {
      searchTerm,
      results,
    },
  };
}
