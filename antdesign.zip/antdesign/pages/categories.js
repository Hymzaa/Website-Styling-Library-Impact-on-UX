import { Layout } from "../components/Layout";
import { fetchAllCategories } from "../lib/categories";
import Link from "next/link";

export default function Categories(props) {
  const categories = props.categories;

  return (
    <Layout>
      {categories.map((category) => (
        <div key={category.id} style={{ cursor: "pointer" }}>
          <Link href={`/category/${category.id}`}>
            <h2>{category.label}</h2>
          </Link>
        </div>
      ))}
    </Layout>
  );
}

export async function getStaticProps() {
  const objectData = await fetchAllCategories();

  return {
    props: {
      categories: objectData,
    },
  };
}
