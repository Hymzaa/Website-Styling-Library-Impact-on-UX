import { Layout } from "../../components/Layout";
import { fetchAllProducts, getProductData } from "../../lib/products";
import useBasket from "../../state/useBasket";

import styles from "../../styles/product.[id].module.css";
import Image from "next/image";
import { Row } from "../../components/Row";
import { useEffect, useState } from "react";
import { fetchAllCategories } from "../../lib/categories";
import Link from "next/link";
import { ShowPrice } from "../../components/ShowPrice";
import { Card, Typography, Space, Button, Breadcrumb } from "antd";

//get the Title JSX from typography ant
const { Title } = Typography;

export default function Product({ productData, categories }) {
  const addToBasket = useBasket((state) => state.addToBasket);
  const updateQuantity = useBasket((state) => state.updateQuantity);

  const _basket = useBasket((state) => state.basket);
  const [basket, setBasket] = useState([]);

  useEffect(() => {
    setBasket(_basket);
  }, [_basket]);

  // calculations
  const findItem = () =>
    basket.find((item) => item.product.id === productData.id);
  const quantity = () => findItem()?.quantity || 0;
  const existsInBasket = () => findItem() != null;

  // intents
  const increase = () => updateQuantity(productData, quantity() + 1);
  const decrease = () => updateQuantity(productData, quantity() - 1);
  const remove = () => updateQuantity(productData, 0);

  return (
    <Layout>
      <Breadcrumb>
        <Link href={`/`} passHref>
          <Breadcrumb.Item>Home</Breadcrumb.Item>
        </Link>
        {categories.map((category) => (
          <Breadcrumb.Item key={category.id}>
            <Link href={`/category/${category.id}`} passHref>
              {category.label}
            </Link>
          </Breadcrumb.Item>
        ))}
      </Breadcrumb>

      <br />
      <Space
        direction="vertical"
        size="middle"
        style={{
          display: "flex",
        }}
      >
        <Card>
          <div className={styles.wrapper}>
            <div className={styles.content}>
              <div className={styles.left}>
                <Image
                  src={productData["image_url"]}
                  layout="fill"
                  objectFit="cover"
                  alt="Placeholder"
                />
              </div>
              <div className={styles.right}>
                <h2 className={styles.productName}>{productData.name}</h2>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Maecenas nec ligula a quam blandit efficitur a ut lacus.
                  Suspendisse scelerisque sagittis massa, ac ornare dui dictum
                  sed. Mauris non laoreet ex. Nam lobortis molestie leo ut
                  pharetra. Fusce laoreet ligula ut massa luctus, vel efficitur
                  ante semper.
                </p>
                <b>Price</b>: <ShowPrice product={productData} />
                <br />
                {existsInBasket() ? (
                  <Row>
                    <Button size="small" onClick={decrease}>
                      -1
                    </Button>
                    <span>{quantity()}</span>
                    <Button size="small" onClick={increase}>
                      +1
                    </Button>
                    <Button size="small" type="danger" onClick={remove}>
                      Remove
                    </Button>
                  </Row>
                ) : (
                  <Button
                    type="primary"
                    onClick={() => addToBasket(productData)}
                  >
                    Add To Basket
                  </Button>
                )}
              </div>
            </div>
          </div>
        </Card>
        <Card title={<Title level={3}>Product Description</Title>}>
          {/*<div className={styles.wrapper}>*/}

          <p>{productData.name}</p>
          <p>Responsibly Sourced*</p>
          <p>
            *Phasellus rhoncus, mauris ac finibus volutpat, felis nunc posuere
            quam, nec interdum enim nunc ac tellus. Phasellus maximus
            ullamcorper sem in convallis. Suspendisse laoreet sit amet metus in
            laoreet. Etiam ac tortor malesuada, consectetur leo ut, dignissim
            mauris. Maecenas commodo maximus orci. Ut maximus vel justo in
            dignissim.
          </p>
          <p>
            Aliquam tincidunt magna at enim condimentum, ut placerat massa
            eleifend.
          </p>
          <p>
            Cras gravida magna vitae mi malesuada blandit. Praesent vel eros
            vehicula, porta lorem ac, dapibus quam. Nam non est a dolor euismod
            ultricies. Nunc eros erat, aliquet sit amet vehicula sit amet,
            cursus a lacus. Proin sem purus, dignissim eget est vel, tincidunt
            iaculis nulla.
          </p>
          <p>
            Pellentesque sapien enim, eleifend ut enim id, blandit consectetur
            purus. Pellentesque tincidunt, nisi non dictum varius, enim risus
            scelerisque quam, eget blandit nunc sem scelerisque felis.
            Suspendisse potenti.
          </p>
        </Card>

        <Card title={<Title level={3}>Information</Title>}>
          <span>
            Nulla id accumsan erat. Nulla posuere tincidunt leo, nec volutpat
            sem condimentum pharetra. Donec iaculis dapibus urna eu faucibus.
            Vestibulum tincidunt arcu est, et tincidunt quam tristique non.
            Phasellus iaculis a dolor eget facilisis. Fusce vel dolor ac turpis
            imperdiet blandit et a leo. Nulla accumsan tellus sed nisl aliquam,
            non ullamcorper lectus tincidunt. Cras porta, erat sed rhoncus
            finibus, orci leo volutpat est, sed placerat tortor tellus vel
            magna. Nunc vel nibh nec dolor pulvinar blandit sit amet ut enim.
            Suspendisse hendrerit purus vel pellentesque tincidunt. Maecenas
            pellentesque nisi lobortis metus imperdiet finibus. In scelerisque
            dui eget eleifend tincidunt. Curabitur non dolor convallis, eleifend
            turpis eu, maximus mi. Pellentesque euismod neque nec orci rhoncus,
            sit amet vestibulum turpis convallis.
          </span>
        </Card>
        {/*</div>*/}

        <div className={styles.pointerWrapper}>
          {productData.categories.map((cat_id) => {
            return (
              <div key={cat_id} style={{ marginBottom: 20 }}>
                <Link href={`/category/${cat_id}`}>
                  <Card>
                    <div className={styles.viewCatContainer}>
                      <div className={styles.viewCatGridItem}>
                        View all{" "}
                        {categories.find((cat) => cat.id == cat_id).label}{" "}
                        products
                      </div>
                    </div>
                  </Card>
                </Link>
              </div>
            );
          })}
        </div>
      </Space>
    </Layout>
  );
}

// return a list of possible value for id
export async function getStaticPaths() {
  const productObjects = await fetchAllProducts();

  const paths = productObjects.map((product) => {
    return {
      params: {
        id: product.id,
      },
    };
  });

  return {
    paths,
    fallback: false,
  };
}

// fetch necessary data for the product page using params.id
export async function getStaticProps({ params }) {
  const productData = await getProductData(params.id);
  const allCategories = await fetchAllCategories();

  const categories = [];
  productData.categories.forEach((categoryId) => {
    allCategories.forEach((categoryObj) => {
      if (categoryObj.id === categoryId.toString()) {
        categories.push(categoryObj);
      }
    });
  });

  return {
    props: {
      productData,
      categories,
    },
  };
}
