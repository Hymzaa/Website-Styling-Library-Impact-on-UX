import { fetchAllProducts } from "../lib/products";
import { Layout } from "../components/Layout";
import Image from "next/image";
import styles from "../styles/index.module.css";
import { fetchLandingPageData } from "../lib/landing_page_data";
import { fetchAllCategories } from "../lib/categories";
import { GridProductItem } from "../components/GridProductItem";
import Link from "next/link";

import { ShowPrice } from "../components/ShowPrice";
import { Button, Card, Typography } from "antd";

export default function Home(props) {
  const { featuredProduct, featuredCategories } = props;

  return (
    <Layout>
      <div className={styles.pointerWrapper} style={{ marginTop: 10 }}>
        <Link href={`/product/${featuredProduct.id}`}>
          <Card>
            <div className={styles.content}>
              <div className={styles.left}>
                <Image
                  src={featuredProduct.image_url}
                  layout="fill"
                  objectFit="cover"
                  alt="Placeholder"
                />
              </div>
              <div className={styles.right}>
                <Typography.Title level={2} className={styles.productName}>
                  {featuredProduct.name}
                </Typography.Title>
                <b>Price:</b>
                <div>
                  <ShowPrice product={featuredProduct} />
                </div>
                <br />
                <Button type="primary">View Product</Button>
                <br />
              </div>
            </div>
          </Card>
        </Link>
      </div>

      <div style={{ marginBottom: 10 }}>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: 30,
            margin: "30px 0",
          }}
        >
          {featuredCategories.map((obj) => {
            let cat_list = [];

            obj.categoryProducts.forEach((product) =>
              cat_list.push(
                <div className={styles.pointerWrapper}>
                  <Card style={{ height: "100%" }}>
                    <GridProductItem
                      product={product}
                      img={
                        <div className={styles.smallProductPicture}>
                          <Image
                            src={product.image_url}
                            layout="fill"
                            objectFit="cover"
                            alt="Placeholder"
                          />
                        </div>
                      }
                    />
                  </Card>
                </div>
              )
            );
            cat_list.push(
              <div className={styles.pointerWrapper}>
                <Link href={`/category/${obj.category.id}`}>
                  <Card
                    style={{
                      height: "100%",
                      width: "100%",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Typography.Title level={4} style={{ textAlign: "center" }}>
                      View All Items
                      <br />
                      in Category
                    </Typography.Title>
                  </Card>
                </Link>
              </div>
            );
            return (
              <div key={obj.category.label}>
                <Typography.Title level={2} style={{ textAlign: "center" }}>
                  {obj.category.label}
                </Typography.Title>
                <div className={styles.container}>{cat_list}</div>
              </div>
            );
          })}
        </div>
        <div className={styles.pointerWrapper}>
          <Link href={`/categories`}>
            <Card>
              <div className={styles.viewCatContainer}>
                <div className={styles.viewCatGridItem}>
                  View All Categories
                </div>
              </div>
            </Card>
          </Link>
        </div>{" "}
      </div>
    </Layout>
  );
}

export async function getStaticProps() {
  const allProducts = await fetchAllProducts();
  const allCategories = await fetchAllCategories();
  const landingPageData = await fetchLandingPageData();

  const featuredProduct = allProducts.find(
    (product) =>
      product.id.toString() ===
      landingPageData["featured_product"].id.toString()
  );

  const featuredCategories = landingPageData["featured_categories"].map(
    (item) => {
      return {
        category: allCategories.find(
          (cat) => cat.id.toString() === item.id.toString()
        ),
        categoryProducts: item["featured_products"].map((productId) =>
          allProducts.find(
            (product) => product.id.toString() === productId.toString()
          )
        ),
      };
    }
  );

  return {
    props: {
      featuredProduct,
      featuredCategories,
    },
  };
}
