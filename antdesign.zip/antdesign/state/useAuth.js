import create from "zustand";
import { persist } from "zustand/middleware";
import { timeout } from "../util/miscellaneous";

const useAuth = create(
  persist(
    (set) => ({
      user: {},
      register: async (name, email, password) => {
        console.log(
          `useAuth.register(name: ${name}, email: ${email}, password: ${password})`
        );
        await timeout(2000);
        set(() => ({
          user: {
            name: "John Doe",
            email: "john@gmail.com",
            password: "john@gmail.com",
          },
        }));
        return true;
      },
      login: async (email, password) => {
        console.log(`useAuth.login(email: ${email}, password: ${password})`);
        await timeout(2000);
        set(() => ({
          user: {
            name: "John Doe",
            email: "john@gmail.com",
            password: "john@gmail.com",
          },
        }));
        return true;
      },
      logout: () => {
        console.log(`useAuth.logout()`);
        set(() => ({
          user: null,
        }));
      },
    }),
    { name: "auth" }
  )
);

export default useAuth;
