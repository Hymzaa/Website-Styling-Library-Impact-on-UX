import create from "zustand";
import { persist } from "zustand/middleware";

const useBasket = create(
  persist(
    (set, get) => ({
      basket: [],
      addToBasket: (product) => {
        const exists = get().basket.find(
          (item) => item.product.id === product.id
        );
        if (!exists) {
          set((state) => ({
            basket: [
              ...state.basket,
              {
                quantity: 1,
                product,
              },
            ],
          }));
        }
      },
      updateQuantity: (product, quantity) => {
        const exists = get().basket.find(
          (item) => item.product.id === product.id
        );
        if (exists && quantity === 0) {
          set((state) => ({
            basket: state.basket.filter(
              (item) => item.product.id !== product.id
            ),
          }));
        } else if (exists) {
          set((state) => ({
            basket: state.basket.map((item) =>
              item.product.id !== product.id
                ? item
                : {
                    quantity,
                    product,
                  }
            ),
          }));
        }
        // returns nothing if item doesn't exist
      },
      clearBasket: () => {
        set(() => ({
          basket: [],
        }));
      },
    }),
    { name: "basket" }
  )
);

export default useBasket;
