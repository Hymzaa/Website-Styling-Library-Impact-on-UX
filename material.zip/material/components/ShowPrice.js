import { formatPrice } from "../util/basketPricing";
import { Typography } from "@mui/material";

export const ShowPrice = ({ product }) => {
  if (product.price != product.original_price) {
    return (
      <span>
        <Typography sx={{ textDecoration: "line-through" }}>
          {formatPrice(product.original_price)}
        </Typography>
        <Typography sx={{ color: "red" }}>
          {formatPrice(product.price)}
        </Typography>
      </span>
    );
  }
  return <Typography>{formatPrice(product.price)}</Typography>;
};
