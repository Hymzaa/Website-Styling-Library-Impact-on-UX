import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/router";

import { basketTotal, formatPrice } from "../util/basketPricing";
import useBasket from "../state/useBasket";

import styles from "../styles/Header.module.css";
import categories from "../data/categories.json";
import useAuth from "../state/useAuth";
import { isEmptyObject } from "../util/miscellaneous";
import { Button, Chip, TextField, Typography } from "@mui/material";

const topHeaderVariant = "body1";

export const Header = () => {
  const router = useRouter();

  const _basket = useBasket((state) => state.basket);
  const [basket, setBasket] = useState([]);

  const logout = useAuth((state) => state.logout);
  const _user = useAuth((state) => state.user);
  const [user, setUser] = useState(null);

  useEffect(() => {
    setBasket(_basket);
    setUser(_user);
  }, [_basket, _user]);

  const [searchTerm, setSearchTerm] = useState("");
  const handleSearch = () => router.push(`/search?=${searchTerm}`);

  const handleAccountClick = () =>
    router.push(!isEmptyObject(user) ? `/account` : `/authenticate`);

  const handleLogoutClick = () => logout();

  return (
    <header>
      <div className={styles.userDetailsWrapper}>
        <div className={styles.userDetails}>
          <a className={styles.account} onClick={handleAccountClick}>
            <Typography variant={topHeaderVariant} onClick={handleAccountClick}>
              {!isEmptyObject(user) ? `Account: ${user.name}` : "Login"}
            </Typography>
          </a>
          {!isEmptyObject(user) ? (
            <Typography variant={topHeaderVariant} onClick={handleLogoutClick}>
              Logout
            </Typography>
          ) : (
            <></>
          )}
          <Link href={`/checkout`}>
            <a>
              <Typography variant={topHeaderVariant}>
                Basket {formatPrice(basketTotal(basket))}
              </Typography>
            </a>
          </Link>
        </div>
      </div>
      <div className={styles.brandAndSearchWrapper}>
        <div className={styles.brandAndSearch}>
          <Link href={`/`}>
            <a>
              <Typography variant="h3">Good Grocery</Typography>
            </a>
          </Link>
          <div className={styles.searchWrapper}>
            <TextField
              id="search-input"
              label="Search for products"
              variant="filled"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Button
              variant="contained"
              color="primary"
              disableElevation
              onClick={handleSearch}
            >
              Search
            </Button>
          </div>
        </div>
      </div>
      <div className={styles.categoriesWrapper}>
        <div className={styles.categories}>
          {categories.map((category) => {
            return (
              <div key={category.id}>
                <Link href={`/category/${category.id}`}>
                  <Chip label={category.label} onClick={() => {}} />
                </Link>
              </div>
            );
          })}
        </div>
      </div>
    </header>
  );
};
