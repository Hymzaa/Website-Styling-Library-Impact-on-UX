import styles from "../styles/ProductListItem.module.css";
import Link from "next/link";
import Image from "next/image";
import { ShowPrice } from "./ShowPrice";
import { Button, Paper, Typography } from "@mui/material";

export const ProductListItem = ({ product, elevation = 1 }) => {
  const { id, name, image_url } = product;
  console.log(product);
  return (
    <Link href={`/product/${id}`}>
      <Paper elevation={elevation}>
        <div className={styles.rootWrapper}>
          <div className={styles.imageWrapper}>
            <Image
              src={image_url}
              layout="fill"
              objectFit="contain"
              alt="Placeholder"
            />
          </div>
          <div className={styles.detailsWrapper}>
            <Typography variant="h5">{name}</Typography>
            <br />
            Price: <ShowPrice product={product} />
            <br />
            <Button variant="contained" className={styles.viewProductButton}>
              View Product
            </Button>
          </div>
        </div>
      </Paper>
    </Link>
  );
};
