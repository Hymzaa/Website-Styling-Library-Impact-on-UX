import styles from "../styles/Footer.module.css";
import {Typography} from "@mui/material";

export const Footer = () => {
  return (
    <div className={styles.footerWrapper}>
      <footer className={styles.footer}>
        <Typography variant="body1">
          Copyright TM, Dissertation Artefact 2022
        </Typography>
      </footer>
    </div>
  );
};
