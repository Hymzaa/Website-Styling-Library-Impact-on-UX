import Head from "next/head";

import styles from "../styles/Layout.module.css";
import { Header } from "./Header";
import { Footer } from "./Footer";

export const Layout = ({ children }) => {
  return (
    <>
      <Head>
        <title>Website</title>
        <meta name="description" content="Website description" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      {/* start of visible content */}

      <Header />
      <div className={styles.container}>
        {/*<hr />*/}
        <main>{children}</main>
        {/*<hr />*/}
      </div>
      <Footer />
    </>
  );
};
