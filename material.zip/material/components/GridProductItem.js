import style from "../styles/GridProductItem.module.css";
import Link from "next/link";
import {Paper, Typography} from "@mui/material";

export const GridProductItem = ({ product, img }) => {
  return (
    <Link href={`/product/${product.id}`}>
      <Paper  sx={{ height: "100%" }}>
        <div className={style.gridItem}>
          {img}
          <Typography variant="h6">
            {product.name}
          </Typography>
        </div>
      </Paper>
    </Link>
  );
};
