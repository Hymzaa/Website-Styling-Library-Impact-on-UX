export const basketTotal = (basket) => {
  let total = 0;
  basket.forEach((item) => {
    total += item.product.price * item.quantity;
  });
  return total;
};

export const formatPrice = (price) => "£" + price.toFixed(2);