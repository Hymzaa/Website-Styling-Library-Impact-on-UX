import {Layout} from "../components/Layout";
import {fetchAllProducts} from "../lib/products";
import styles from "../styles/category.[id].module.css";
import {ProductListItem} from "../components/ProductListItem";
import {Typography} from "@mui/material";

export default function Search({searchTerm, results}) {
  return (
    <Layout>
      <Typography variant="h4">Search: &quot;{searchTerm}&quot;</Typography>
      <br/>

      <div className={styles.productList}>
        {results.map((product) => (
          <ProductListItem key={product.id} product={product}/>
        ))}
      </div>

      <br />
    </Layout>
  );
}

export async function getServerSideProps({query}) {
  // the query term is default bc there is no named url params
  const searchTerm = query[""];

  const allProducts = await fetchAllProducts();

  const results = allProducts.filter(
    (product) => product.name.toLowerCase() === searchTerm.toLowerCase()
  );

  return {
    props: {
      searchTerm,
      results,
    },
  };
}
