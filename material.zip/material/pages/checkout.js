import { useEffect, useState } from "react";
import Link from "next/link";

import { Layout } from "../components/Layout";
import useBasket from "../state/useBasket";
import Item from "../components/Item";
import { Row } from "../components/Row";

import styles from "../styles/checkout.module.css";
import { formatPrice } from "../util/basketPricing";
import useAuth from "../state/useAuth";
import { isEmptyObject } from "../util/miscellaneous";
import { ProductListItem } from "../components/ProductListItem";
import {
  Button,
  Card,
  CardContent,
  FormControlLabel,
  Paper,
  Radio,
  RadioGroup,
  Typography,
} from "@mui/material";

export default function Checkout() {
  const updateQuantity = useBasket((state) => state.updateQuantity);
  const clearBasket = useBasket((state) => state.clearBasket);

  const _user = useAuth((state) => state.user);
  const [user, setUser] = useState(null);

  const _basket = useBasket((state) => state.basket);
  const [basket, setBasket] = useState([]);

  useEffect(() => {
    setUser(_user);
    setBasket(_basket);
  }, [_user, _basket]);

  // calculations
  const subtotal = (item) => item.quantity * item.product.price;
  const total = () =>
    basket.reduce((sum, item) => sum + item.quantity * item.product.price, 0);

  // intents
  const increase = (item) => updateQuantity(item.product, item.quantity + 1);
  const decrease = (item) => updateQuantity(item.product, item.quantity - 1);
  const remove = (item) => updateQuantity(item.product, 0);

  const handleContinue = () => {
    if (isEmptyObject(user)) {
      alert("Please sign in to continue checkout.");
    } else {
      alert("Your order has been placed!");
      clearBasket();
    }
  };

  return (
    <Layout>
      <Typography variant="h4">Checkout</Typography>

      {basket.length === 0 ? (
        <>
          <h3>Empty Basket</h3>
        </>
      ) : (
        <div className={styles.checkoutBasketWrapper}>
          <div>
            {basket.map((item) => (
              <Paper key={item.product.id} style={{ marginBottom: 20 }}>
                <Item>
                  <Link href={`/product/${item.product.id}`}>
                    <div className={styles.basketItem}>
                      <ProductListItem
                        elevation={0}
                        key={item.product.id}
                        product={item.product}
                      />
                    </div>
                  </Link>

                  <div className={styles.basketItemQuanSubControls}>
                    <Typography
                      variant="subtitle2"
                      style={{
                        fontSize: 15,
                        marginBottom: 10,
                      }}
                    >
                      Subtotal: {formatPrice(subtotal(item))}
                    </Typography>
                    <Row>
                      <Button
                        size="small"
                        style={{ minWidth: 40 }}
                        variant="contained"
                        color="secondary"
                        onClick={() => decrease(item)}
                      >
                        -1
                      </Button>
                      <Typography variant="subtitle1">{item.quantity}</Typography>
                      <Button
                        size="small"
                        style={{ minWidth: 40 }}
                        variant="contained"
                        color="secondary"
                        onClick={() => increase(item)}
                      >
                        +1
                      </Button>
                      <Button
                        size="small"
                        variant="contained"
                        onClick={() => remove(item)}
                      >
                        Remove
                      </Button>
                    </Row>
                  </div>
                </Item>
              </Paper>
            ))}
            <Button variant="outlined" color="error" onClick={clearBasket}>
              Clear Basket
            </Button>
          </div>
          <div className={styles.paymentWrapper}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Confirm Order
                </Typography>
                <div className={styles.prices}>
                  <Typography variant="body2">
                    Total (excl. VAT): {formatPrice(total() * 0.8)}
                  </Typography>
                  <br />
                  <Typography variant="body2">
                    VAT (20%): {formatPrice(total() * 0.2)}
                  </Typography>
                  <br />
                  <Typography className={styles.total}>
                    Total incl. taxes: {formatPrice(total())}
                  </Typography>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Delivery Address
                </Typography>
                <Paper
                  elevation={0}
                  variant="outlined"
                  className={styles.deliveryAddress}
                >
                  <br />
                  <Typography>71 Kingsway</Typography>
                  <Typography>London</Typography>
                  <Typography>NW59 0WT</Typography>
                  <br />
                  <Button variant="outlined">Update</Button>
                </Paper>
              </CardContent>
            </Card>

            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Payment Method
                </Typography>
                <div>
                  <RadioGroup className={styles.paymentOptionList}>
                    <Paper
                      elevation={0}
                      variant="outlined"
                      className={styles.paymentOption}
                    >
                      <div className={styles.paymentDetails}>
                        <FormControlLabel
                          value="option-1"
                          control={<Radio />}
                        />
                        <div>
                          <Typography variant="subtitle2">
                            <b>VISA 8734</b>
                          </Typography>
                          <Typography variant="body2">07/25</Typography>
                        </div>
                      </div>
                      <Button variant="outlined">Edit</Button>
                    </Paper>

                    <Paper
                      elevation={0}
                      variant="outlined"
                      className={styles.paymentOption}
                    >
                      <div className={styles.paymentDetails}>
                        <FormControlLabel
                          value="option-2"
                          control={<Radio />}
                        />
                        <div>
                          <Typography variant="subtitle2">
                            <b>AMEX 3492</b>
                          </Typography>
                          <Typography variant="body2">07/25</Typography>
                        </div>
                      </div>
                      <Button variant="outlined">Edit</Button>
                    </Paper>
                  </RadioGroup>
                </div>
              </CardContent>
            </Card>

            <Button
              variant="contained"
              className={styles.paymentConfirm}
              onClick={handleContinue}
            >
              Confirm Order
            </Button>
          </div>
        </div>
      )}
    </Layout>
  );
}
