import { fetchAllProducts } from "../lib/products";
import { Layout } from "../components/Layout";
import Image from "next/image";
import styles from "../styles/index.module.css";
import { fetchLandingPageData } from "../lib/landing_page_data";
import { fetchAllCategories } from "../lib/categories";
import { GridProductItem } from "../components/GridProductItem";
import Link from "next/link";
import { ShowPrice } from "../components/ShowPrice";
import { Button, Paper, Typography } from "@mui/material";

export default function Home(props) {
  const { featuredProduct, featuredCategories } = props;

  return (
    <Layout>
      <div className={styles.pointerWrapper}>
        <Link href={`/product/${featuredProduct.id}`}>
          <Paper >
            <div className={styles.wrapper}>
              <div className={styles.content}>
                <div className={styles.left}>
                  <Image
                    src={featuredProduct.image_url}
                    layout="fill"
                    objectFit="cover"
                    alt="Placeholder"
                  />
                </div>
                <div className={styles.right}>
                  <Typography variant="h4">{featuredProduct.name}</Typography>
                  <br />
                  <Typography sx={{ fontWeight: "bold" }}>Price:</Typography>
                  <div>
                    <ShowPrice product={featuredProduct} />
                  </div>
                  <br />
                  <Button variant="contained">View Product</Button>
                </div>
              </div>
            </div>
          </Paper>
        </Link>
      </div>

      <div>
        <br />
        <div>
          {featuredCategories.map((obj) => {
            let cat_list = [];

            obj.categoryProducts.forEach((product) =>
              cat_list.push(
                <div key={product.id} className={styles.pointerWrapper}>
                  <GridProductItem
                    product={product}
                    img={
                      <div className={styles.smallProductPicture}>
                        <Image
                          src={product.image_url}
                          layout="fill"
                          objectFit="cover"
                          alt="Placeholder"
                        />
                      </div>
                    }
                  />
                </div>
              )
            );
            cat_list.push(
              <div key={obj.category.label} className={styles.pointerWrapper}>
                <Link href={`/category/${obj.category.id}`}>
                  <Paper
                    
                    sx={{ height: "100%" }}
                    className={styles.gridItem}
                  >
                    <Typography variant="h6">View All Items</Typography>
                    <Typography variant="h6">in Category</Typography>
                  </Paper>
                </Link>
              </div>
            );
            return (
              <div key={obj.category.label}>
                <Typography variant="h5" className={styles.categories}>
                  {obj.category.label}
                </Typography>
                <div className={styles.container}>{cat_list}</div>
              </div>
            );
          })}
        </div>
        <div className={styles.pointerWrapper}>
          <Paper >
            <Link href={`/categories`}>
              <div className={styles.viewAllProductContainer}>
                <div className={styles.viewAllProductGridItem}>
                  <Typography variant="h6">View All Categories</Typography>
                </div>
              </div>
            </Link>
          </Paper>
        </div>
      </div>
    </Layout>
  );
}

export async function getStaticProps() {
  const allProducts = await fetchAllProducts();
  const allCategories = await fetchAllCategories();
  const landingPageData = await fetchLandingPageData();

  const featuredProduct = allProducts.find(
    (product) =>
      product.id.toString() ===
      landingPageData["featured_product"].id.toString()
  );

  const featuredCategories = landingPageData["featured_categories"].map(
    (item) => {
      return {
        category: allCategories.find(
          (cat) => cat.id.toString() === item.id.toString()
        ),
        categoryProducts: item["featured_products"].map((productId) =>
          allProducts.find(
            (product) => product.id.toString() === productId.toString()
          )
        ),
      };
    }
  );

  return {
    props: {
      featuredProduct,
      featuredCategories,
    },
  };
}
