import { Layout } from "../../components/Layout";
import { fetchAllProducts, getProductData } from "../../lib/products";
import useBasket from "../../state/useBasket";

import styles from "../../styles/product.[id].module.css";
import Image from "next/image";
import { Row } from "../../components/Row";
import { useEffect, useState } from "react";
import { fetchAllCategories } from "../../lib/categories";
import Link from "next/link";
import { ShowPrice } from "../../components/ShowPrice";
import { Breadcrumbs, Button, Paper, Typography } from "@mui/material";

export default function Product({ productData, categories }) {
  const addToBasket = useBasket((state) => state.addToBasket);
  const updateQuantity = useBasket((state) => state.updateQuantity);

  const _basket = useBasket((state) => state.basket);
  const [basket, setBasket] = useState([]);

  useEffect(() => {
    setBasket(_basket);
  }, [_basket]);

  // calculations
  const findItem = () =>
    basket.find((item) => item.product.id === productData.id);
  const quantity = () => findItem()?.quantity || 0;
  const existsInBasket = () => findItem() != null;

  // intents
  const increase = () => updateQuantity(productData, quantity() + 1);
  const decrease = () => updateQuantity(productData, quantity() - 1);
  const remove = () => updateQuantity(productData, 0);

  return (
    <Layout>
      <Breadcrumbs aria-label="breadcrumb">
        <Link href={`/`}>Home</Link>
        {categories.map((category) => (
          <div key={category.id}>
            <Link href={`/category/${category.id}`}>{category.label}</Link>
          </div>
        ))}
      </Breadcrumbs>
      <br />

      <Paper  className={styles.wrapper}>
        <div className={styles.content}>
          <div className={styles.left}>
            <Image
              src={productData["image_url"]}
              layout="fill"
              objectFit="cover"
              alt="Placeholder"
            />
          </div>
          <div className={styles.right}>
            <Typography variant="h4">{productData.name}</Typography>
            <br />
            <Typography>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas
              nec ligula a quam blandit efficitur a ut lacus. Suspendisse
              scelerisque sagittis massa, ac ornare dui dictum sed. Mauris non
              laoreet ex. Nam lobortis molestie leo ut pharetra. Fusce laoreet
              ligula ut massa luctus, vel efficitur ante semper.
            </Typography>
            <br />
            <b>Price</b>: <ShowPrice product={productData} />
            <br />
            {existsInBasket() ? (
              <Row>
                <Button
                  variant="contained"
                  color="secondary"
                  onClick={decrease}
                >
                  -1
                </Button>
                <Typography variant="subtitle1">{quantity()}</Typography>
                <Button
                  variant="contained"
                  color="secondary"
                  onClick={increase}
                >
                  +1
                </Button>
                <Button variant="contained" onClick={remove}>
                  Remove
                </Button>
              </Row>
            ) : (
              <Button
                variant="contained"
                onClick={() => addToBasket(productData)}
              >
                Add To Basket
              </Button>
            )}
          </div>
        </div>
      </Paper>
      <Paper  className={styles.wrapper}>
        <Typography variant="h5">Product Description</Typography>
        <br />
        <Typography>{productData.name}</Typography>
        <br />
        <Typography>Responsibly Sourced*</Typography>
        <br />
        <Typography>
          *Phasellus rhoncus, mauris ac finibus volutpat, felis nunc posuere
          quam, nec interdum enim nunc ac tellus. Phasellus maximus ullamcorper
          sem in convallis. Suspendisse laoreet sit amet metus in laoreet. Etiam
          ac tortor malesuada, consectetur leo ut, dignissim mauris. Maecenas
          commodo maximus orci. Ut maximus vel justo in dignissim.
        </Typography>
        <br />
        <Typography>
          Aliquam tincidunt magna at enim condimentum, ut placerat massa
          eleifend.
        </Typography>
        <br />
        <Typography>
          Cras gravida magna vitae mi malesuada blandit. Praesent vel eros
          vehicula, porta lorem ac, dapibus quam. Nam non est a dolor euismod
          ultricies. Nunc eros erat, aliquet sit amet vehicula sit amet, cursus
          a lacus. Proin sem purus, dignissim eget est vel, tincidunt iaculis
          nulla.
        </Typography>
        <br />
        <Typography>
          Pellentesque sapien enim, eleifend ut enim id, blandit consectetur
          purus. Pellentesque tincidunt, nisi non dictum varius, enim risus
          scelerisque quam, eget blandit nunc sem scelerisque felis. Suspendisse
          potenti.
        </Typography>
      </Paper>
      <Paper  className={styles.wrapper}>
        <Typography variant="h5">Information</Typography>
        <br />
        <Typography>
          Nulla id accumsan erat. Nulla posuere tincidunt leo, nec volutpat sem
          condimentum pharetra. Donec iaculis dapibus urna eu faucibus.
          Vestibulum tincidunt arcu est, et tincidunt quam tristique non.
          Phasellus iaculis a dolor eget facilisis. Fusce vel dolor ac turpis
          imperdiet blandit et a leo. Nulla accumsan tellus sed nisl aliquam,
          non ullamcorper lectus tincidunt. Cras porta, erat sed rhoncus
          finibus, orci leo volutpat est, sed placerat tortor tellus vel magna.
          Nunc vel nibh nec dolor pulvinar blandit sit amet ut enim. Suspendisse
          hendrerit purus vel pellentesque tincidunt. Maecenas pellentesque nisi
          lobortis metus imperdiet finibus. In scelerisque dui eget eleifend
          tincidunt. Curabitur non dolor convallis, eleifend turpis eu, maximus
          mi. Pellentesque euismod neque nec orci rhoncus, sit amet vestibulum
          turpis convallis.
        </Typography>
      </Paper>
      <div className={styles.pointerWrapper}>
        {productData.categories.map((cat_id) => {
          return (
            <div key={cat_id}>
              <Link href={`/category/${cat_id}`}>
                <Paper  className={styles.viewCatContainer}>
                  <div className={styles.viewCatGridItem}>
                    View all {categories.find((cat) => cat.id == cat_id).label}{" "}
                    products
                  </div>
                </Paper>
              </Link>
            </div>
          );
        })}
      </div>
    </Layout>
  );
}

// return a list of possible value for id
export async function getStaticPaths() {
  const productObjects = await fetchAllProducts();

  const paths = productObjects.map((product) => {
    return {
      params: {
        id: product.id,
      },
    };
  });

  return {
    paths,
    fallback: false,
  };
}

// fetch necessary data for the product page using params.id
export async function getStaticProps({ params }) {
  const productData = await getProductData(params.id);
  const allCategories = await fetchAllCategories();

  const categories = [];
  productData.categories.forEach((categoryId) => {
    allCategories.forEach((categoryObj) => {
      if (categoryObj.id === categoryId.toString()) {
        categories.push(categoryObj);
      }
    });
  });

  return {
    props: {
      productData,
      categories,
    },
  };
}
