import { Layout } from "../components/Layout";
import { useEffect, useState } from "react";

import styles from "../styles/login.module.css";
import useAuth from "../state/useAuth";
import { useRouter } from "next/router";
import {isEmptyObject} from "../util/miscellaneous";
import {Button, TextField, Typography} from "@mui/material";

export default function Authenticate() {
  const router = useRouter();

  const _user = useAuth((state) => state.user);
  const login = useAuth((state) => state.login);
  const register = useAuth((state) => state.register);

  const [loading, setLoading] = useState(false);
  const [registerSelected, setRegisterSelected] = useState(false);

  // input fields
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  useEffect(() => {
    // user cannot go into this page if they are logged in
    if (!isEmptyObject(_user)) router.push(`/`);
  }, [_user, router]);

  const handleModeSwitch = () => {
    if (!loading) setRegisterSelected(!registerSelected);
  };

  const handleValidation = () => {
    if (registerSelected) {
      password === confirmPassword
        ? handleRegister()
        : alert("Password and confirm password not matching.");
    } else handleLogin();
  };

  const handleLogin = async () => {
    setLoading(true);
    const res = await login(email, password);
    if (res) await router.push(`/`);
    else {
      setLoading(false);
      alert("Failed to login.");
    }
  };

  const handleRegister = async () => {
    setLoading(true);
    const res = await register(name, email, password);
    if (res) await router.push(`/`);
    else {
      setLoading(false);
      alert("Failed to register.");
    }
  };

  return (
    <Layout>
      <div className={`${styles.wrapper} ${loading ? styles.loading : ""}`}>
        <Typography variant="h4">{registerSelected ? "Register" : "Log into your account"}</Typography>
        <Typography className={styles.switch} onClick={handleModeSwitch}>
          {registerSelected
            ? "Already have an account? Click here to sign in."
            : "Don't have an account? Click here to register."}
        </Typography>
        {registerSelected ? (
          <div>
            <TextField
              label="Name"
              disabled={loading}
              className={styles.input}
              type="text"
              placeholder=""
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
        ) : (
          <></>
        )}
        <div>
          <TextField
            label="Email"
            disabled={loading}
            className={styles.input}
            type="text"
            placeholder="e.g. name@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div>
          <TextField
            label="Password"
            disabled={loading}
            className={styles.input}
            type="password"
            placeholder=""
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        {registerSelected ? (
          <div>
            <TextField
              label="Confirm Password"
              disabled={loading}
              className={styles.input}
              type="password"
              placeholder=""
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
            />
          </div>
        ) : (
          <></>
        )}
        <Button
          variant="contained"
          className={styles.continue}
          onClick={handleValidation}
          disabled={loading}
        >
          {registerSelected ? "Create your account" : "Login"}
        </Button>
      </div>
    </Layout>
  );
}
