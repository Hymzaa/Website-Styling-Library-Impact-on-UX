/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    domains: ['digitalcontent.api.tesco.com'],
  },
}

module.exports = nextConfig
