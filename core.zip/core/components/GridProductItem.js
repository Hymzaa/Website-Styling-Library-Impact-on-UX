import style from "../styles/GridProductItem.module.css";
import Link from "next/link";

export const GridProductItem = ({ product, img }) => {
  return (
    <Link href={`/product/${product.id}`}>
      <div className={style.gridItem}>
        {img}
        {product.name}
      </div>
    </Link>
  );
};
