import { Layout } from "../components/Layout";
import useAuth from "../state/useAuth";
import { isEmptyObject } from "../util/miscellaneous";
import { useEffect, useState } from "react";
import { useRouter } from "next/router";

import styles from "../styles/account.module.css";
import Image from "next/image";

export default function Account() {
  const router = useRouter();

  const _user = useAuth((state) => state.user);
  const [user, setUser] = useState(null);

  useEffect(() => {
    if (isEmptyObject(_user)) router.push(`/authenticate`);
    setUser(_user);
  }, [_user, router]);

  const orderData = [
    {
      id: 1,
      date: "20th August 2022",
      total: 10.39,
      productImages: [
        "https://digitalcontent.api.tesco.com/v2/media/ghs/1ffd7683-3d9f-4c2d-8a8d-3d67c29c7d17/78eec1fd-2834-47a0-aa99-f9d398f4f796_222616424.jpeg?h=540&w=540",
        "https://digitalcontent.api.tesco.com/v2/media/ghs/7ae55910-3dd7-43bb-b89a-d00236927866/ac24df22-2111-47eb-b1bc-c0abf8688c45_250325805.jpeg?h=540&w=540",
        "https://digitalcontent.api.tesco.com/v2/media/ghs/2903431d-622a-4e84-94cf-af11212247a5/c9479a90-e9c8-473d-97cc-ee16a3580598_1088088421.jpeg?h=540&w=540",
        "https://digitalcontent.api.tesco.com/v2/media/ghs/9c44f2c3-157c-4770-a85a-c87ad913cdc1/4170908f-f5d3-400d-b072-2cd916771aea_1918001748.jpeg?h=540&w=540",
      ],
    },

    {
      id: 2,
      date: "15th August 2022",
      total: 21.98,
      productImages: [
        "https://digitalcontent.api.tesco.com/v2/media/ghs/8def6f07-d68e-43a0-bc4f-117efd9628c1/b35a54d0-883f-47f4-9f9e-76061511c491.jpeg?h=540&w=540",
        "https://digitalcontent.api.tesco.com/v2/media/ghs/e737456f-8d0d-4ac4-92ac-da48c0c61148/dedd1c2f-8a68-4063-860d-bbdef88f4aa0.jpeg?h=540&w=540",
        "https://digitalcontent.api.tesco.com/v2/media/ghs/a58f48a6-7dc1-4ea3-a876-a4ab3da24f32/ec683ffd-579f-48f9-b98d-ff76bd33bd16.jpeg?h=540&w=540",
        "https://digitalcontent.api.tesco.com/v2/media/ghs/331fcda6-2a41-481f-a46f-016be9fe0519/1c505b1e-b18a-4fc9-97e8-25bba2279a2e_438900266.jpeg?h=540&w=540",
      ],
    },
  ];

  return user == null || isEmptyObject(user) ? (
    <></>
  ) : (
    <Layout>
      <h2>Welcome, {user.name}.</h2>
      <div className={styles.wrapper}>
        <div className={styles.personalDetailWrapper}>
          <h3>Personal Details</h3>
          <div className={styles.accountDetail}>
            <div>
              <b>Full Name</b>
              <p>{user.name}</p>
            </div>
            <button>Update</button>
          </div>
          <div className={styles.accountDetail}>
            <div>
              <b>Email Address</b>
              <p>{user.email}</p>
            </div>
            <button>Update</button>
          </div>
          <div className={styles.accountDetail}>
            <div>
              <b>Password</b>
              <p>********</p>
            </div>
            <button>Update</button>
          </div>
        </div>
        <div className={styles.orderHistoryWrapper}>
          <h3>Orders History</h3>
          <div className={styles.orderList}>
            {orderData.map((orderDataItem) => (
              <div key={orderDataItem.id} className={styles.order}>
                <div className={styles.orderDetails}>
                  <b>{orderDataItem.date}</b>
                  <span>Total: £{orderDataItem.total}</span>
                </div>
                <div className={styles.orderedItems}>
                  {orderDataItem.productImages.map((imageUrl) => (
                    <div
                      key={imageUrl.toString()}
                      className={styles.productImage}
                    >
                      <Image
                        src={imageUrl.toString()}
                        width={540}
                        height={540}
                        layout="responsive"
                        objectFit="cover"
                        alt="Placeholder"
                      />
                    </div>
                  ))}
                </div>
                <button className={styles.receiptButton}>
                  View Full Receipt
                </button>
              </div>
            ))}
            {/*<div className={styles.order}>*/}
            {/*  <div className={styles.orderDetails}>*/}
            {/*    <b>20th August 2022</b>*/}
            {/*    <span>Total: £10.39</span>*/}
            {/*  </div>*/}
            {/*  <div className={styles.orderedItems}>*/}
            {/*    {[1, 2, 3, 4].map((product) => (*/}
            {/*      <div className={styles.orderItem}></div>*/}
            {/*    ))}*/}
            {/*  </div>*/}
            {/*  <button className={styles.receiptButton}>*/}
            {/*    View Full Receipt*/}
            {/*  </button>*/}
            {/*</div>*/}
            {/*<div className={styles.order}>*/}
            {/*  <div className={styles.orderDetails}>*/}
            {/*    <b>15th August 2022</b>*/}
            {/*    <span>Total: £21.98</span>*/}
            {/*  </div>*/}
            {/*  <div className={styles.orderedItems}>*/}
            {/*    {[1, 2, 3, 4].map((product) => (*/}
            {/*      <div className={styles.orderItem}></div>*/}
            {/*    ))}*/}
            {/*  </div>*/}
            {/*  <button className={styles.receiptButton}>*/}
            {/*    View Full Receipt*/}
            {/*  </button>*/}
            {/*</div>*/}
          </div>
        </div>
      </div>
    </Layout>
  );
}
