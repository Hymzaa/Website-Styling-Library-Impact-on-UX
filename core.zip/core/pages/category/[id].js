import { Layout } from "../../components/Layout";
import {
  fetchAllCategories,
  getCategoryData,
  getCategoryProducts,
} from "../../lib/categories";
import { ProductListItem } from "../../components/ProductListItem";

import styles from "../../styles/category.[id].module.css";

export default function Category({ categoryData, categoryProductList }) {
  return (
    <Layout>
      <h1>Category: {categoryData.label}</h1>

      {categoryProductList.length === 0 ? (
        <h2>No products in this category.</h2>
      ) : (
        <></>
      )}

      <div className={styles.productList}>
        {categoryProductList.map((product) => (
          <ProductListItem key={product.id} product={product} />
        ))}
      </div>
    </Layout>
  );
}

export async function getStaticPaths() {
  const categoryObjects = await fetchAllCategories();

  const paths = categoryObjects.map((category) => {
    return {
      params: {
        id: category.id,
      },
    };
  });

  return {
    paths,
    fallback: false,
  };
}

export async function getStaticProps({ params }) {
  const categoryData = await getCategoryData(params.id);
  const categoryProductList = await getCategoryProducts(params.id);

  return {
    props: {
      categoryData,
      categoryProductList,
    },
  };
}
