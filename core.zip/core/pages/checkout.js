import { useEffect, useState } from "react";
import Link from "next/link";

import { Layout } from "../components/Layout";
import useBasket from "../state/useBasket";
import Item from "../components/Item";
import { Row } from "../components/Row";

import styles from "../styles/checkout.module.css";
import { formatPrice } from "../util/basketPricing";
import useAuth from "../state/useAuth";
import { isEmptyObject } from "../util/miscellaneous";
import { ProductListItem } from "../components/ProductListItem";

export default function Checkout() {
  const updateQuantity = useBasket((state) => state.updateQuantity);
  const clearBasket = useBasket((state) => state.clearBasket);

  const _user = useAuth((state) => state.user);
  const [user, setUser] = useState(null);

  const _basket = useBasket((state) => state.basket);
  const [basket, setBasket] = useState([]);

  useEffect(() => {
    setUser(_user);
    setBasket(_basket);
  }, [_user, _basket]);

  // calculations
  const subtotal = (item) => item.quantity * item.product.price;
  const total = () =>
    basket.reduce((sum, item) => sum + item.quantity * item.product.price, 0);

  // intents
  const increase = (item) => updateQuantity(item.product, item.quantity - 1);
  const decrease = (item) => updateQuantity(item.product, item.quantity + 1);
  const remove = (item) => updateQuantity(item.product, 0);

  const handleContinue = () => {
    if (isEmptyObject(user)) {
      alert("Please sign in to continue checkout.")
    } else {
      alert("Your order has been placed!")
      clearBasket()
    }
  };

  return (
    <Layout>
      <h2>Checkout</h2>
      {basket.length === 0 ? (
        <>
          <h3>Empty Basket</h3>
        </>
      ) : (
        <div className={styles.checkoutBasketWrapper}>
          <div>
            {basket.map((item) => (
              <div key={item.product.id}>
                <Item>
                  <Link href={`/product/${item.product.id}`}>
                    <div className={styles.basketItem}>
                      <ProductListItem
                        key={item.product.id}
                        product={item.product}
                      />
                    </div>
                  </Link>

                  <div className={styles.basketItemQuanSubControls}>
                    <p>Subtotal: {formatPrice(subtotal(item))}</p>

                    <Row>
                      <button onClick={() => increase(item)}>-1</button>
                      <span>{item.quantity}</span>
                      <button onClick={() => decrease(item)}>+1</button>
                      <button onClick={() => remove(item)}>Remove</button>
                    </Row>
                  </div>
                </Item>
              </div>
            ))}
            <button onClick={clearBasket}>Clear Basket</button>
          </div>
          <div className={styles.paymentWrapper}>
            <h3>Confirm Order</h3>
            <div className={styles.prices}>
              <span>Total (excl. VAT): {formatPrice(total() * 0.8)}</span>
              <br />
              <span>VAT (20%): {formatPrice(total() * 0.2)}</span>
              <br />
              <span className={styles.total}>
                Total incl. taxes: {formatPrice(total())}
              </span>
            </div>
            <h4>Delivery Address</h4>
            <div className={styles.deliveryAddress}>
              <p>71 Kingsway</p>
              <p>London</p>
              <p>NW59 0WT</p>
              <button>Update</button>
            </div>
            <h4>Payment Method</h4>
            <div className={styles.paymentOptionList}>
              <div className={styles.paymentOption}>
                <div className={styles.paymentDetails}>
                  <input type="radio" />
                  <div>
                    <span>
                      <b>VISA 8734</b>
                    </span>
                    <br />
                    <span>07/25</span>
                  </div>
                </div>
                <button>Edit</button>
              </div>
              <div className={styles.paymentOption}>
                <div className={styles.paymentDetails}>
                  <input type="radio" />
                  <div>
                    <span>
                      <b>AMEX 3492</b>
                    </span>
                    <br />
                    <span>07/25</span>
                  </div>
                </div>
                <button>Edit</button>
              </div>
            </div>
            <button className={styles.paymentConfirm} onClick={handleContinue}>
              Confirm Order
            </button>
          </div>
        </div>
      )}
    </Layout>
  );
}
