import { Layout } from "../components/Layout";
import { useEffect, useState } from "react";

import styles from "../styles/login.module.css";
import useAuth from "../state/useAuth";
import { useRouter } from "next/router";
import {isEmptyObject} from "../util/miscellaneous";

export default function Authenticate() {
  const router = useRouter();

  const _user = useAuth((state) => state.user);
  const login = useAuth((state) => state.login);
  const register = useAuth((state) => state.register);

  const [loading, setLoading] = useState(false);
  const [registerSelected, setRegisterSelected] = useState(false);

  // input fields
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  useEffect(() => {
    // user cannot go into this page if they are logged in
    if (!isEmptyObject(_user)) router.push(`/`);
  }, [_user, router]);

  const handleModeSwitch = () => {
    if (!loading) setRegisterSelected(!registerSelected);
  };

  const handleValidation = () => {
    if (registerSelected) {
      password === confirmPassword
        ? handleRegister()
        : alert("Password and confirm password not matching.");
    } else handleLogin();
  };

  const handleLogin = async () => {
    setLoading(true);
    const res = await login(email, password);
    if (res) await router.push(`/`);
    else {
      setLoading(false);
      alert("Failed to login.");
    }
  };

  const handleRegister = async () => {
    setLoading(true);
    const res = await register(name, email, password);
    if (res) await router.push(`/`);
    else {
      setLoading(false);
      alert("Failed to register.");
    }
  };

  return (
    <Layout>
      <div className={`${styles.wrapper} ${loading ? styles.loading : ""}`}>
        <h2>{registerSelected ? "Register" : "Log into your account"}</h2>
        <p className={styles.switch} onClick={handleModeSwitch}>
          {registerSelected
            ? "Already have an account? Click here to sign in."
            : "Don't have an account? Click here to register."}
        </p>
        {registerSelected ? (
          <div>
            <h3>Name</h3>
            <input
              disabled={loading}
              className={styles.input}
              type="text"
              placeholder=""
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
        ) : (
          <></>
        )}
        <div>
          <h3>Email</h3>
          <input
            disabled={loading}
            className={styles.input}
            type="text"
            placeholder="e.g. name@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div>
          <h3>Password</h3>
          <input
            disabled={loading}
            className={styles.input}
            type="password"
            placeholder=""
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        {registerSelected ? (
          <div>
            <h3>Confirm Password</h3>
            <input
              disabled={loading}
              className={styles.input}
              type="password"
              placeholder=""
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
            />
          </div>
        ) : (
          <></>
        )}
        <button
          className={styles.continue}
          onClick={handleValidation}
          disabled={loading}
        >
          {registerSelected ? "Create your account" : "Login"}
        </button>
      </div>
    </Layout>
  );
}
