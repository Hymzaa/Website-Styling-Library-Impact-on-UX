import { fetchAllProducts } from "../lib/products";
import { Layout } from "../components/Layout";
import Image from "next/image";
import styles from "../styles/index.module.css";
import { fetchLandingPageData } from "../lib/landing_page_data";
import { fetchAllCategories } from "../lib/categories";
import { GridProductItem } from "../components/GridProductItem";
import Link from "next/link";
import { ShowPrice } from "../components/ShowPrice";

export default function Home(props) {
  const { featuredProduct, featuredCategories } = props;

  return (
    <Layout>
      <div className={styles.pointerWrapper}>
        <Link href={`/product/${featuredProduct.id}`}>
          <div className={styles.wrapper}>
            <div className={styles.content}>
              <div className={styles.left}>
                <Image
                  src={featuredProduct.image_url}
                  layout="fill"
                  objectFit="cover"
                  alt="Placeholder"
                />
              </div>
              <div className={styles.right}>
                <h2 className={styles.productName}>{featuredProduct.name}</h2>
                <b>Price</b>:{" "}
                <div>
                  <ShowPrice product={featuredProduct} />
                </div>
                <br />
                <button>View Product</button>
                <br />
              </div>
            </div>
          </div>
        </Link>
      </div>

      <div>
        <br />
        <div>
          {featuredCategories.map((obj) => {
            let cat_list = [];

            obj.categoryProducts.forEach((product) =>
              cat_list.push(
                <div className={styles.pointerWrapper}>
                  <GridProductItem
                    product={product}
                    img={
                      <div className={styles.smallProductPicture}>
                        <Image
                          src={product.image_url}
                          layout="fill"
                          objectFit="cover"
                          alt="Placeholder"
                        />
                      </div>
                    }
                  />
                </div>
              )
            );
            cat_list.push(
              <div className={styles.pointerWrapper}>
                <Link href={`/category/${obj.category.id}`}>
                  <div className={styles.gridItem}>All items in category</div>
                </Link>
              </div>
            );
            return (
              <div key={obj.category.label}>
                <h2 className={styles.categories}>{obj.category.label}</h2>
                <div className={styles.container}>{cat_list}</div>
              </div>
            );
          })}
        </div>
        <div className={styles.pointerWrapper}>
          <Link href={`/categories`}>
            <div className={styles.viewAllProductContainer}>
              <div className={styles.viewAllProductGridItem}>
                View all categories
              </div>
            </div>
          </Link>
        </div>{" "}
      </div>
    </Layout>
  );
}

export async function getStaticProps() {
  const allProducts = await fetchAllProducts();
  const allCategories = await fetchAllCategories();
  const landingPageData = await fetchLandingPageData();

  const featuredProduct = allProducts.find(
    (product) =>
      product.id.toString() ===
      landingPageData["featured_product"].id.toString()
  );

  const featuredCategories = landingPageData["featured_categories"].map(
    (item) => {
      return {
        category: allCategories.find(
          (cat) => cat.id.toString() === item.id.toString()
        ),
        categoryProducts: item["featured_products"].map((productId) =>
          allProducts.find(
            (product) => product.id.toString() === productId.toString()
          )
        ),
      };
    }
  );

  return {
    props: {
      featuredProduct,
      featuredCategories,
    },
  };
}
