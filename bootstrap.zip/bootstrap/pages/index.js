import { fetchAllProducts } from "../lib/products";
import { Layout } from "../components/Layout";

import styles from "../styles/index.module.css";
import { fetchLandingPageData } from "../lib/landing_page_data";
import { fetchAllCategories } from "../lib/categories";
import { GridProductItem } from "../components/GridProductItem";
import Link from "next/link";

import { ShowPrice } from "../components/ShowPrice";
import { Card, Button, Row, Col } from "react-bootstrap";

export default function Home(props) {
  const { featuredProduct, featuredCategories } = props;

  return (
    <Layout>
      <div className={styles.pointerWrapper} style={{ marginBottom: 50 }}>
        <Link href={`/product/${featuredProduct.id}`}>
          <Card bg="light" className="card flex-row flex-wrap">
            <div className="col-md-5">
              <Card.Img variant="top" src={featuredProduct.image_url} />
            </div>
            <div className="card-block px-5">
              <Card.Body>
                <div className={styles.featuredProductTextWrapper}>
                  <Card.Title>
                    <h2 className={styles.productName}>
                      {featuredProduct.name}
                    </h2>
                  </Card.Title>
                  <b>Price</b>:
                  <div>
                    <ShowPrice product={featuredProduct} />
                  </div>
                  <br />
                  <Button>View Product</Button>
                  <br />
                </div>
              </Card.Body>
            </div>
          </Card>
        </Link>
      </div>
      <div>
        <div>
          {featuredCategories.map((obj) => {
            let cat_list = [];
            obj.categoryProducts.forEach((product) =>
              cat_list.push(
                <div key={obj.category.label} className={styles.pointerWrapper}>
                  <GridProductItem product={product} img={product.image_url} />
                </div>
              )
            );
            cat_list.push(
              <Col>
                <div className={styles.pointerWrapper}>
                  <Card style={{ height: "24rem" }}>
                    <Card.Body>
                      <Link href={`/category/${obj.category.id}`}>
                        <div className={styles.gridItem}>
                          View All Items
                          <br />
                          in Category
                        </div>
                      </Link>
                    </Card.Body>
                  </Card>
                </div>
              </Col>
            );
            return (
              <div key={obj.category.label} className={styles.gridItemWrapper}>
                <Row>
                  <h2 className={styles.categories}>{obj.category.label}</h2>
                  <div className={styles.container}>{cat_list}</div>
                </Row>
              </div>
            );
          })}
        </div>

        <div className={styles.pointerWrapper}>
          <Link href={`/categories`}>
            <Card style={{ height: "7rem" }}>
              <Card.Body>
                <div className={styles.viewAllProductContainer}>
                  <div className={styles.viewAllProductGridItem}>
                    View all categories
                  </div>
                </div>
              </Card.Body>
            </Card>
          </Link>
        </div>
      </div>
    </Layout>
  );
}

export async function getStaticProps() {
  const allProducts = await fetchAllProducts();
  const allCategories = await fetchAllCategories();
  const landingPageData = await fetchLandingPageData();

  const featuredProduct = allProducts.find(
    (product) =>
      product.id.toString() ===
      landingPageData["featured_product"].id.toString()
  );

  const featuredCategories = landingPageData["featured_categories"].map(
    (item) => {
      return {
        category: allCategories.find(
          (cat) => cat.id.toString() === item.id.toString()
        ),
        categoryProducts: item["featured_products"].map((productId) =>
          allProducts.find(
            (product) => product.id.toString() === productId.toString()
          )
        ),
      };
    }
  );

  return {
    props: {
      featuredProduct,
      featuredCategories,
    },
  };
}
