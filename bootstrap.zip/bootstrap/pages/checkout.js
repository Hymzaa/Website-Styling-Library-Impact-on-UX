import { useEffect, useState } from "react";
import Link from "next/link";

import { Layout } from "../components/Layout";
import useBasket from "../state/useBasket";
import Item from "../components/Item";
import { Row } from "../components/Row";

import styles from "../styles/checkout.module.css";
import { formatPrice } from "../util/basketPricing";
import useAuth from "../state/useAuth";
import { isEmptyObject } from "../util/miscellaneous";
import { ProductListItem } from "../components/ProductListItem";
import { Button, Card, ListGroup, Form } from "react-bootstrap";

export default function Checkout() {
  const updateQuantity = useBasket((state) => state.updateQuantity);
  const clearBasket = useBasket((state) => state.clearBasket);

  const _user = useAuth((state) => state.user);
  const [user, setUser] = useState(null);

  const _basket = useBasket((state) => state.basket);
  const [basket, setBasket] = useState([]);

  useEffect(() => {
    setUser(_user);
    setBasket(_basket);
  }, [_user, _basket]);

  // calculations
  const subtotal = (item) => item.quantity * item.product.price;
  const total = () =>
    basket.reduce((sum, item) => sum + item.quantity * item.product.price, 0);

  // intents
  const increase = (item) => updateQuantity(item.product, item.quantity - 1);
  const decrease = (item) => updateQuantity(item.product, item.quantity + 1);
  const remove = (item) => updateQuantity(item.product, 0);

  const handleContinue = () => {
    if (isEmptyObject(user)) {
      alert("Please sign in to continue checkout.");
    } else {
      alert("Your order has been placed!");
      clearBasket();
    }
  };

  return (
    <Layout>
      <h2>Checkout</h2>
      <br />
      {basket.length === 0 ? (
        <>
          <h3>Empty Basket</h3>
        </>
      ) : (
        <div className={styles.checkoutBasketWrapper}>
          <div>
            {basket.map((item) => (
              <div key={item.product.id}>
                <Card>
                  <Item>
                    <Link href={`/product/${item.product.id}`}>
                      <Card border="light">
                        <Card.Body>
                          <div className={styles.basketItem}>
                            <ProductListItem
                              key={item.product.id}
                              product={item.product}
                            />
                          </div>
                        </Card.Body>
                      </Card>
                    </Link>
                    <div className={styles.basketItemQuanSubControls}>
                      <p>Subtotal: {formatPrice(subtotal(item))}</p>
                      <Row>
                        <Button
                          variant="secondary"
                          onClick={() => increase(item)}
                        >
                          -1
                        </Button>
                        <>{item.quantity}</>
                        <Button
                          variant="secondary"
                          onClick={() => decrease(item)}
                        >
                          +1
                        </Button>
                        <Button variant="danger" onClick={() => remove(item)}>
                          Remove
                        </Button>
                      </Row>
                    </div>
                  </Item>
                </Card>
                <br />
              </div>
            ))}
            <Button variant="danger" onClick={clearBasket}>
              Clear Basket
            </Button>
          </div>
          <div className={styles.paymentWrapper}>
            <Card>
              <Card.Header>
                <div className={styles.cardHeaderText}>Confirm Order</div>
              </Card.Header>
              <Card.Body>
                <Card.Text>
                  <div className={styles.prices}>
                    <span>Total (excl. VAT): {formatPrice(total() * 0.8)}</span>
                    <br />
                    <span>VAT (20%): {formatPrice(total() * 0.2)}</span>
                    <br />
                    <span className={styles.total}>
                      Total incl. taxes: {formatPrice(total())}
                    </span>
                  </div>
                </Card.Text>
              </Card.Body>
            </Card>
            <br />
            <Card>
              <Card.Header>
                <div className={styles.cardHeaderText}>Delivery Address</div>
              </Card.Header>
              <Card.Body>
                <Card.Text>
                  <span>71 Kingsway</span>
                  <br />
                  <span>London</span>
                  <br />
                  <span>NW59 0WT</span>
                </Card.Text>
              </Card.Body>
              <Card.Footer>
                <Button>Update</Button>
              </Card.Footer>
            </Card>
            <br />
            <Card>
              <Card.Header>
                <div className={styles.cardHeaderText}>Payment Method</div>
              </Card.Header>
              <Card.Body>
                <div className={styles.paymentOptionList}>
                  <ListGroup>
                    <ListGroup.Item>
                      <div className={styles.paymentOption}>
                        <div className={styles.paymentDetails}>
                          <Form.Check inline />
                          <div>
                            <span>
                              <b>VISA 8734</b>
                            </span>
                            <br />
                            <span>07/25</span>
                          </div>
                        </div>
                        <Button variant="secondary">Edit</Button>
                      </div>
                    </ListGroup.Item>
                    <ListGroup.Item>
                      <div className={styles.paymentOption}>
                        <div className={styles.paymentDetails}>
                          <Form.Check inline />
                          <div>
                            <span>
                              <b>AMEX 3492</b>
                            </span>
                            <br />
                            <span>07/25</span>
                          </div>
                        </div>
                        <Button variant="secondary">Edit</Button>
                      </div>
                    </ListGroup.Item>
                  </ListGroup>
                </div>
              </Card.Body>
              <Card.Footer>
                {" "}
                <Button
                  onClick={handleContinue}
                >
                  Confirm Order
                </Button>
              </Card.Footer>
            </Card>
          </div>
        </div>
      )}
    </Layout>
  );
}
