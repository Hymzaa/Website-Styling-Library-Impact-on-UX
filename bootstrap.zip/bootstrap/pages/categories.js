import { Layout } from "../components/Layout";
import { fetchAllCategories } from "../lib/categories";
import Link from "next/link";
import {ListGroup} from "react-bootstrap";

export default function Categories(props) {
  const categories = props.categories;

  return (
    <Layout>
      <ListGroup variant="flush">
      {categories.map((category) => (
        <div key={category.id} style={{ cursor: "pointer" }}>
          <Link href={`/category/${category.id}`}>
            <ListGroup.Item><h4>{category.label}</h4></ListGroup.Item>
          </Link>
        </div>
      ))}</ListGroup>
    </Layout>
  );
}

export async function getStaticProps() {
  const objectData = await fetchAllCategories();

  return {
    props: {
      categories: objectData,
    },
  };
}
