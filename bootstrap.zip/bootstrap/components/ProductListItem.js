import styles from "../styles/ProductListItem.module.css";
import Link from "next/link";
import Image from "next/image";
import { ShowPrice } from "./ShowPrice";
import { ListGroup, Button } from "react-bootstrap";

export const ProductListItem = ({ product }) => {
  const { id, name, image_url } = product;
  console.log(product);
  return (
    <Link href={`/product/${id}`}>
      <ListGroup.Item variant="light">
        <div className={styles.rootWrapper}>
          <div className={styles.imageWrapper}>
            <Image
              src={image_url}
              layout="fill"
              objectFit="contain"
              alt="Placeholder"
            />
          </div>
          <div className={styles.detailsWrapper}>
            <h3 className={styles.productName}>{name}</h3>
            <div style={{ margin: "10px 0" }}>
              Price: <ShowPrice product={product} />
            </div>
            <Button className={styles.viewProductButton}>View Product</Button>
          </div>
        </div>
      </ListGroup.Item>
    </Link>
  );
};
