import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import { basketTotal, formatPrice } from "../util/basketPricing";
import useBasket from "../state/useBasket";
import styles from "../styles/Header.module.css";
import categories from "../data/categories.json";
import useAuth from "../state/useAuth";
import { isEmptyObject } from "../util/miscellaneous";
import { Button, Form, Navbar, Badge } from "react-bootstrap";

export const Header = () => {
  const router = useRouter();

  const _basket = useBasket((state) => state.basket);
  const [basket, setBasket] = useState([]);

  const logout = useAuth((state) => state.logout);
  const _user = useAuth((state) => state.user);
  const [user, setUser] = useState(null);

  useEffect(() => {
    setBasket(_basket);
    setUser(_user);
  }, [_basket, _user]);

  const [searchTerm, setSearchTerm] = useState("");
  const handleSearch = () => router.push(`/search?=${searchTerm}`);

  const handleAccountClick = () =>
    router.push(!isEmptyObject(user) ? `/account` : `/authenticate`);

  const handleLogoutClick = () => logout();

  return (
    <header>
      <div className={styles.userDetailsWrapper}>
        <div className={styles.userDetails}>
          <Button
            variant="link"
            size="sm"
            onClick={handleAccountClick}
            style={{ color: "black" }}
          >
            {!isEmptyObject(user) ? `Account: ${user.name}` : "Login"}
          </Button>
          {!isEmptyObject(user) ? (
            <Button
              variant="link"
              size="sm"
              onClick={handleLogoutClick}
              style={{ color: "black" }}
            >
              Logout
            </Button>
          ) : (
            <></>
          )}
          <Link href={`/checkout`}>
            <a>
              <Button variant="link" size="sm" style={{ color: "black" }}>
                Basket {formatPrice(basketTotal(basket))}
              </Button>
            </a>
          </Link>
        </div>
      </div>
      <div className={styles.brandAndSearchWrapper}>
        <div className={styles.brandAndSearch}>
          <Navbar.Brand>
            <Link href={`/`}>
              <h1>Good Grocery</h1>
            </Link>
          </Navbar.Brand>
          <Form className={styles.searchSection}>
            <Form.Control
              className={styles.searchInput}
              type="text"
              placeholder="Search for products"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Button
              variant="success"
              className={styles.searchButton}
              onClick={handleSearch}
            >
              Search
            </Button>
          </Form>
        </div>
      </div>

      <div className={styles.navBarWrapper}>
        <div className={styles.categories}>
          {categories.map((category) => {
            return (
              <div key={category.id}>
                <Link href={`/category/${category.id}`}>
                  <Badge
                    pill
                    bg="light"
                    text="dark"
                    style={{ fontSize: 14, padding: 12 }}
                  >
                    {category.label}
                  </Badge>
                </Link>
              </div>
            );
          })}
        </div>
      </div>
    </header>
  );
};
