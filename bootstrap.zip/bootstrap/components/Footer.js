import styles from "../styles/Footer.module.css";

export const Footer = () => {
  return (
    <div className={styles.footerWrapper}>
      <footer className={styles.footer}>
        <p>Copyright TM, Dissertation Artefact 2022</p>
      </footer>
    </div>
  );
};
