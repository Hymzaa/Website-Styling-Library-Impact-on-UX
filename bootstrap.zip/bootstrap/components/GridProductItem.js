import Link from "next/link";
import { Card, Col, Container } from "react-bootstrap";

export const GridProductItem = ({ product, img }) => {
  return (
    <Link href={`/product/${product.id}`}>
      <Container>
        <Col>
          <Card style={{ height: "24rem" }}>
            <Card.Img variant="top" src={img} />
            <Card.Body>
              <div className="text-center">{product.name}</div>
            </Card.Body>
          </Card>
        </Col>
      </Container>
    </Link>
  );
};
